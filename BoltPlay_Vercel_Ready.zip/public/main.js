const games = [
  {id:'runner', title:'Runner', icon:'🏃'},
  {id:'racer', title:'Racer', icon:'🏎️'},
  {id:'shooter', title:'Shooter', icon:'🚀'}
];

let featuredIndex = 0;
function rotateFeatured(){
  const f = games[featuredIndex];
  document.getElementById('featured-title').innerText = f.title;
  featuredIndex = (featuredIndex + 1) % games.length;
}
setInterval(rotateFeatured, 5000);
rotateFeatured();

function loadGrid(){
  const grid = document.getElementById('game-grid');
  grid.innerHTML='';
  games.forEach((g,i)=>{
    const card=document.createElement('div');
    card.className='p-4 bg-white rounded-xl shadow text-center card-anim';
    card.style.animationDelay = (i*0.1)+'s';
    card.innerHTML=`<div class='text-4xl'>${g.icon}</div><div class='mt-2 font-bold'>${g.title}</div>`;
    card.onclick=()=>alert('Game load placeholder: '+g.id);
    grid.appendChild(card);
  });
}
function playFeatured(){ alert('Play Featured Game'); }
loadGrid();
